# fishes > 2022-04-20 10:18pm
https://universe.roboflow.com/object-detection/fishes-i110o

Provided by Roboflow
License: CC BY 4.0

